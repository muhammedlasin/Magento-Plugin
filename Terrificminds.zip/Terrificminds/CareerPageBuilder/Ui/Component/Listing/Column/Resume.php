<?php 

namespace Terrificminds\CareerPageBuilder\Ui\Component\Listing\Column;

use Magento\Backend\Model\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Ui\Component\Listing\Columns\Column;

class Resume extends Column {

  /**
   *
   * @var StoreManagerInterface
   */
  protected $storeManagerInterface;

  public function __construct(
    ContextInterface $context,
    UiComponentFactory $uiComponentFactory,
    StoreManagerInterface $storeManagerInterface,
    array $components = [],
    array $data = []
  ) {
      parent::__construct($context, $uiComponentFactory, $components, $data);
      $this->storeManagerInterface = $storeManagerInterface;
  }

  public function prepareDataSource(array $dataSource)
  {
    $url = $this->storeManagerInterface->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
    if(isset($dataSource['data']['items'])){
      $fieldName = $this->getData('name');

      $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
      $logger = new \Zend_Log();
      $logger->addWriter($writer);
      $logger->info("/////////////////-----logger initiated-----//////////////////////");
      $logger->info("field   " . print_r($fieldName, true));
      // $logger->info("20   " . print_r($s, true));
      foreach($dataSource["data"]["items"] as & $item) {
        if(!empty($item[$fieldName])){
          $item[$fieldName.'_src'] = $url. 'uploads/' .$item[$fieldName];
          $item[$fieldName.'_alt'] = '';
          $item[$fieldName.'_orig_src'] = $url. 'uploads/' .$item[$fieldName];
        }   
    }
    }
    return $dataSource;
  }
}
